package com.example.cruddemorecode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudDemoRecodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudDemoRecodeApplication.class, args);
	}

}
