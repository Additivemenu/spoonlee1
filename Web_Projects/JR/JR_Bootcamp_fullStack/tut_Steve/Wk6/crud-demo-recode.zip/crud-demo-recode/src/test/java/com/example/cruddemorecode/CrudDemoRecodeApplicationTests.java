package com.example.cruddemorecode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudDemoRecodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
