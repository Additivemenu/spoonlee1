package com.fiona.weatherapp.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class WeatherController {
}
