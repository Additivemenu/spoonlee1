package com.jiangren.bootcamp.java;

public class Outgoing {
  public void callMe() {
    System.out.println("I have been called");
  }
}
