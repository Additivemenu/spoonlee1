package com.jiangren.bootcamp.java;

public interface IBottleNumber {
  String action();

  String pronoun();

  String numberString();

  String container();
}
